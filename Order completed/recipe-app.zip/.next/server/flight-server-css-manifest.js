self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\page.js": [
      "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\page.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\page.module.css"
    ],
    "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\layout.js": [
      "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\globals.css"
    ]
  },
  "cssModules": {
    "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\page": [
      "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\page.module.css",
      "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\page.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\PC\\Downloads\\next js\\Assignment4\\Assignment4\\recipe-app\\app\\globals.css"
    ]
  }
}